package lab5b;

public class Facade {

    public static void main(String[] args){
        args = new String[] {"SampleFacade", "acceptance_test/us1.txt"};
        EazyAccept.main(args);
    }
}
