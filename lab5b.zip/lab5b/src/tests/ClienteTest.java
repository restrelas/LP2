package tests;

import static org.junit.jupiter.api.Assertions.*;

class ClienteTest {

    @org.junit.jupiter.api.Test
    void toString1() {
    }

    @org.junit.jupiter.api.Test
    void setNome() {
    }

    @org.junit.jupiter.api.Test
    void setLocal() {
    }

    @org.junit.jupiter.api.Test
    void setEmail() {
    }
}