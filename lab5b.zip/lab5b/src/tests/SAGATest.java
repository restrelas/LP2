package tests;

import static org.junit.jupiter.api.Assertions.*;

class SAGATest {

    @org.junit.jupiter.api.Test
    void cadastrarCliente() {
    }

    @org.junit.jupiter.api.Test
    void exibeCliente() {
    }

    @org.junit.jupiter.api.Test
    void exibeClientes() {
    }

    @org.junit.jupiter.api.Test
    void editaCliente() {
    }

    @org.junit.jupiter.api.Test
    void removeCliente() {
    }
}