package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProdutoTest {

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPreco() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

}
