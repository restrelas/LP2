package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IdProdutoTest {

	@Test
	void testIdProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testGetNome() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDescricao() {
		fail("Not yet implemented");
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

}
