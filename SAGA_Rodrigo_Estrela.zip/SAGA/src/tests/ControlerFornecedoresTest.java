package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ControlerFornecedoresTest {

	@Test
	void testControlerFornecedores() {
		fail("Not yet implemented");
	}

	@Test
	void testAdicionaFornecedor() {
		fail("Not yet implemented");
	}

	@Test
	void testExibeFornecedor() {
		fail("Not yet implemented");
	}

	@Test
	void testExibeFornecedores() {
		fail("Not yet implemented");
	}

	@Test
	void testEditaFornecedor() {
		fail("Not yet implemented");
	}

	@Test
	void testRemoveFornecedor() {
		fail("Not yet implemented");
	}

	@Test
	void testAdicionaProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testExibeProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testEditaProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testRemoveProduto() {
		fail("Not yet implemented");
	}

}
